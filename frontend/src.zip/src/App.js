
import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import CourseList from "./components/CourseList";
import CourseDetail from "./components/CourseDetail";
import Login from "./components/Login";
import Logout from "./components/Logout";  // Import Logout
import PrivateRoute from "./components/PrivateRoute";  

const App = () => {
  const token = localStorage.getItem("access_token"); // Check if user is logged in
  console.log("🔍 React App Loaded"); // Debugging step
    return (
        <Router>
            {/* Navbar - Only Show Logout If Logged In */}
            {token && (
                <div className="p-4 bg-gray-200 flex justify-between">
                    <h1 className="text-xl font-bold">Tutorly</h1>
                    <Logout /> {/* Logout button appears only if logged in */}
                </div>
            )}

            <Routes>
                {/* Public Route: Login (Redirect to Courses If Already Logged In) */}
                <Route path="/login" element={token ? <Navigate to="/" /> : <Login />} />

                {/* Protected Routes */}
                <Route path="/" element={<PrivateRoute><CourseList /></PrivateRoute>} />
                <Route path="/course/:id" element={<PrivateRoute><CourseDetail /></PrivateRoute>} />

                {/* Catch-All Route Redirecting to Login */}
                <Route path="*" element={<Navigate to="/login" />} />
            </Routes>
        </Router>
    );
};

export default App;
