import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";

const CourseDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [course, setCourse] = useState(null);
    const [relatedCourses, setRelatedCourses] = useState([]);
    const [rating, setRating] = useState(0);
    const [feedback, setFeedback] = useState("");
    const [feedbackMessage, setFeedbackMessage] = useState("");

    const token = localStorage.getItem("token");

    useEffect(() => {
        const fetchCourseDetails = async () => {
            try {
                const response = await axios.get(`http://127.0.0.1:8000/api/courses/${id}/`, {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setCourse(response.data);
                setRelatedCourses(response.data.related_courses || []);
            } catch (error) {
                console.error("Failed to fetch course details:", error);
            }
        };

        fetchCourseDetails();
    }, [id, token]);

    const handleFeedbackSubmit = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post(
                `http://127.0.0.1:8000/api/courses/${id}/feedback/`,
                { rating, feedback },
                {
                    headers: { Authorization: `Bearer ${token}` },
                }
            );
            setFeedbackMessage("Feedback submitted successfully!");
            setRating(0);
            setFeedback("");
            console.log("✅ Feedback Response:", response.data);
        } catch (error) {
            console.error("Failed to submit feedback:", error);
            setFeedbackMessage("Failed to submit feedback.");
        }
    };

    return (
        <div className="p-4">
            {/* Logout Button */}
            <div className="flex justify-end">
                <button
                    className="bg-red-500 text-white font-bold py-1 px-4 rounded hover:bg-red-600"
                    onClick={() => {
                        localStorage.removeItem("token");
                        navigate("/login");
                    }}
                >
                    Logout
                </button>
            </div>

            {/* Course Details */}
            {course ? (
                <div>
                    <h1 className="text-2xl font-bold">{course.title}</h1>
                    <p className="mt-2">
                        <strong>Description:</strong> {course.description}
                    </p>
                    <p className="mt-2">
                        <strong>Rating:</strong> {course.rating.toFixed(2)}
                    </p>

                    {/* Feedback Form */}
                    <h2 className="mt-4 text-xl font-semibold">Rate this Course</h2>
                    <p className="text-red-500">{feedbackMessage}</p>
                    <form onSubmit={handleFeedbackSubmit} className="mt-2">
                        <div className="mb-2">
                            <label className="block text-sm font-medium">Rating (1-5):</label>
                            <input
                                type="number"
                                min="1"
                                max="5"
                                value={rating}
                                onChange={(e) => setRating(e.target.value)}
                                className="border rounded px-2 py-1 w-full"
                                required
                            />
                        </div>
                        <div className="mb-4">
                            <label className="block text-sm font-medium">Feedback:</label>
                            <textarea
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                                className="border rounded px-2 py-1 w-full"
                                rows="3"
                                required
                            ></textarea>
                        </div>
                        <button
                            type="submit"
                            className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-600"
                        >
                            Submit Feedback
                        </button>
                    </form>

                    {/* Related Courses */}
                    <h2 className="mt-6 text-xl font-semibold">Related Courses</h2>
                    <ul className="list-disc pl-5">
                        {relatedCourses.map((related) => (
                            <li key={related.id}>{related.title}</li>
                        ))}
                    </ul>
                </div>
            ) : (
                <p>Loading course details...</p>
            )}
        </div>
    );
};

export default CourseDetail;
