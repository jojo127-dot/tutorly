import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";  // ✅ Import Link for navigation

const CourseList = () => {
    const [courses, setCourses] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchCourses = async () => {
            const token = localStorage.getItem("access_token");

            if (!token) {
                setError("You must be logged in to view courses.");
                return;
            }

            try {
                const response = await axios.get("http://127.0.0.1:8000/api/courses/", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setCourses(response.data);
            } catch (error) {
                console.error("Error fetching courses:", error);
                setError("Failed to load courses. Please try again.");
            }
        };

        fetchCourses();
    }, []);

    return (
        <div className="container mx-auto p-4">
            <h1 className="text-2xl font-bold mb-4">Courses</h1>

            {error && <p className="text-red-500">{error}</p>}

            {courses.length === 0 ? (
                <p>Loading courses...</p>
            ) : (
                <ul className="list-disc pl-5">
                    {courses.map((course) => (
                        <li key={course.id} className="mb-2">
                            <Link to={`/course/${course.id}`} className="text-blue-500 hover:underline">
                                {course.title}
                            </Link>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default CourseList;
